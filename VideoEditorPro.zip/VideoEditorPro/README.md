# Video Editor Pro (Android, Kotlin + Jetpack Compose + Media3)

## Kaise chalayein
1. Android Studio (Koala ya naya) me **Open** -> is folder ko chuno
2. Gradle sync hone do (internet on)
3. Phone connect karo (USB debugging ON) ya emulator -> green Run button

## Features (v2.0)
- Multi-clip timeline (thumbnails, playhead, tap-to-seek)
- Split, Trim, Delete, Duplicate, Reorder (Left/Right)
- Speed (0.25x - 4x), per-clip volume
- 8 filters (B&W, Sepia, Warm, Cool, Bright, Vivid, Drama...) + "apply to all"
- Timed text overlays (size, colour, position, start/end)
- Background music (gaana import + volume)
- Aspect ratio: Original, 9:16, 16:9, 1:1, 4:5
- Export (H.264/AAC) with progress, gallery me save: Movies/VideoEditorPro

## Folder structure
- `EditorViewModel.kt`  -> poora editing state + player + export control
- `engine/Exporter.kt` -> Media3 Transformer composition (clips, effects, text, music)
- `engine/FilterEffects.kt`, `engine/VolumeProcessor.kt`
- `ui/EditorScreen.kt` -> saari screens/panels
- `model/Models.kt`

## Aage kya add kar sakte hain (roadmap)
Transitions, keyframes, stickers/images overlay, PiP / multi-layer, auto captions,
chroma key, undo/redo, project save/load (Room), reverse, freeze frame, voice-over.
