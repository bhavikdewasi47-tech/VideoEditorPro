package com.example.videoeditor

import android.app.Application
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.example.videoeditor.engine.Exporter
import com.example.videoeditor.engine.FilterEffects
import com.example.videoeditor.model.AspectOption
import com.example.videoeditor.model.Clip
import com.example.videoeditor.model.ExportStatus
import com.example.videoeditor.model.FilterType
import com.example.videoeditor.model.MusicTrack
import com.example.videoeditor.model.TextItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.atomic.AtomicLong

class EditorViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx = app.applicationContext
    private val ids = AtomicLong(1)

    // ---------- State ----------
    var clips by mutableStateOf<List<Clip>>(emptyList()); private set
    var texts by mutableStateOf<List<TextItem>>(emptyList()); private set
    var music by mutableStateOf<MusicTrack?>(null); private set
    var aspect by mutableStateOf(AspectOption.ORIGINAL); private set
    var selectedClipId by mutableStateOf<Long?>(null); private set
    var selectedTextId by mutableStateOf<Long?>(null); private set
    var positionMs by mutableLongStateOf(0L); private set
    var isPlaying by mutableStateOf(false); private set
    var isImporting by mutableStateOf(false); private set

    var exportStatus by mutableStateOf(ExportStatus.IDLE); private set
    var exportProgress by mutableFloatStateOf(0f); private set
    var exportMessage by mutableStateOf(""); private set

    val totalMs: Long get() = clips.sumOf { it.effectiveDurationMs }
    val activeClip: Clip? get() = clips.find { it.id == selectedClipId } ?: clips.firstOrNull()
    val activeText: TextItem? get() = texts.find { it.id == selectedTextId }

    fun previewAspect(): Float {
        aspect.ratio?.let { return it }
        val c = clips.firstOrNull() ?: return 16f / 9f
        return (c.width.toFloat() / c.height.toFloat()).coerceIn(0.3f, 3f)
    }

    // ---------- Players ----------
    val player: ExoPlayer = ExoPlayer.Builder(ctx).build()
    private val musicPlayer: ExoPlayer = ExoPlayer.Builder(ctx).build()
    private var appliedFilter: FilterType? = null
    private var transformer: Transformer? = null

    init {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                applyClipSettings(player.currentMediaItemIndex)
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    musicPlayer.pause()
                    positionMs = totalMs
                }
            }
        })
        viewModelScope.launch {
            while (true) {
                if (player.isPlaying) positionMs = timelinePosition().coerceAtMost(totalMs)
                delay(40)
            }
        }
    }

    private fun timelinePosition(): Long {
        val idx = player.currentMediaItemIndex
        var t = 0L
        for (i in 0 until idx.coerceAtMost(clips.size)) t += clips[i].effectiveDurationMs
        val c = clips.getOrNull(idx) ?: return t
        return t + (player.currentPosition / c.speed).toLong()
    }

    /** Timeline time -> (clip index, clip ke andar media offset) */
    private fun locate(timelineMs: Long): Pair<Int, Long> {
        var acc = 0L
        for ((i, c) in clips.withIndex()) {
            val d = c.effectiveDurationMs
            if (timelineMs < acc + d || i == clips.lastIndex) {
                val off = (timelineMs - acc).coerceIn(0L, d)
                val mediaLen = c.endMs - c.startMs
                val media = (off * c.speed).toLong().coerceAtMost((mediaLen - 1).coerceAtLeast(0L))
                return i to media
            }
            acc += d
        }
        return 0 to 0L
    }

    private fun applyClipSettings(index: Int) {
        val c = clips.getOrNull(index) ?: return
        player.setPlaybackSpeed(c.speed)
        player.volume = c.volume.coerceIn(0f, 1f)
        if (appliedFilter != c.filter) {
            player.setVideoEffects(FilterEffects.forFilter(c.filter))
            appliedFilter = c.filter
        }
    }

    private fun rebuildPlayer(timelineMs: Long) {
        player.pause()
        musicPlayer.pause()
        if (clips.isEmpty()) {
            player.clearMediaItems()
            positionMs = 0L
            return
        }
        val t = timelineMs.coerceIn(0L, totalMs)
        positionMs = t
        val items = clips.map { c ->
            MediaItem.Builder()
                .setUri(c.uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(c.startMs)
                        .setEndPositionMs(c.endMs)
                        .build()
                )
                .build()
        }
        val (i, off) = locate(t)
        player.setMediaItems(items, i, off)
        player.prepare()
        applyClipSettings(i)
    }

    // ---------- Playback ----------
    fun togglePlay() {
        if (clips.isEmpty()) return
        if (player.isPlaying) {
            player.pause()
            musicPlayer.pause()
        } else {
            if (positionMs >= totalMs - 50) seekTo(0L)
            player.play()
            if (music != null) {
                musicPlayer.seekTo(positionMs)
                musicPlayer.play()
            }
        }
    }

    fun seekTo(timelineMs: Long) {
        if (clips.isEmpty()) return
        val t = timelineMs.coerceIn(0L, totalMs)
        positionMs = t
        val (i, off) = locate(t)
        player.seekTo(i, off)
        applyClipSettings(i)
        if (music != null && player.isPlaying) musicPlayer.seekTo(t)
    }

    // ---------- Import ----------
    private fun probe(uri: Uri): Clip? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                ?: return null
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1920
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 1080
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) {
                val tmp = w; w = h; h = tmp
            }
            Clip(
                id = ids.getAndIncrement(), uri = uri,
                sourceDurationMs = dur, startMs = 0L, endMs = dur,
                width = w, height = h
            )
        } catch (e: Exception) {
            null
        } finally {
            r.release()
        }
    }

    fun addClips(uris: List<Uri>) {
        if (uris.isEmpty()) return
        isImporting = true
        viewModelScope.launch {
            val newClips = withContext(Dispatchers.IO) { uris.mapNotNull { probe(it) } }
            isImporting = false
            if (newClips.isEmpty()) return@launch
            clips = clips + newClips
            if (selectedClipId == null) selectedClipId = newClips.first().id
            rebuildPlayer(positionMs)
        }
    }

    // ---------- Clip editing ----------
    fun selectClip(id: Long) {
        selectedClipId = id
        selectedTextId = null
    }

    fun editClip(id: Long, rebuild: Boolean = false, f: (Clip) -> Clip) {
        clips = clips.map { if (it.id == id) f(it) else it }
        if (positionMs > totalMs) positionMs = totalMs
        if (rebuild) rebuildPlayer(positionMs) else applyClipSettings(player.currentMediaItemIndex)
    }

    fun trimClip(id: Long, startMs: Long, endMs: Long) {
        editClip(id, rebuild = true) { it.copy(startMs = startMs, endMs = endMs) }
    }

    fun applyFilterToAll(filter: FilterType) {
        clips = clips.map { it.copy(filter = filter) }
        applyClipSettings(player.currentMediaItemIndex)
    }

    fun splitAtPlayhead() {
        val t = positionMs
        var acc = 0L
        for ((i, c) in clips.withIndex()) {
            val d = c.effectiveDurationMs
            if (t > acc && t < acc + d) {
                val splitSrc = c.startMs + ((t - acc) * c.speed).toLong()
                if (splitSrc - c.startMs < 300 || c.endMs - splitSrc < 300) return
                val a = c.copy(endMs = splitSrc)
                val b = c.copy(id = ids.getAndIncrement(), startMs = splitSrc)
                clips = clips.toMutableList().apply {
                    removeAt(i)
                    add(i, a)
                    add(i + 1, b)
                }
                selectedClipId = b.id
                rebuildPlayer(t)
                return
            }
            acc += d
        }
    }

    fun deleteActiveClip() {
        val id = activeClip?.id ?: return
        val idx = clips.indexOfFirst { it.id == id }
        clips = clips.filter { it.id != id }
        selectedClipId = clips.getOrNull(idx.coerceAtMost(clips.lastIndex))?.id
        rebuildPlayer(positionMs)
    }

    fun duplicateActiveClip() {
        val c = activeClip ?: return
        val idx = clips.indexOfFirst { it.id == c.id }
        val copy = c.copy(id = ids.getAndIncrement())
        clips = clips.toMutableList().apply { add(idx + 1, copy) }
        selectedClipId = copy.id
        rebuildPlayer(positionMs)
    }

    fun moveActiveClip(dir: Int) {
        val id = activeClip?.id ?: return
        val i = clips.indexOfFirst { it.id == id }
        val j = i + dir
        if (j !in clips.indices) return
        clips = clips.toMutableList().apply {
            val c = removeAt(i)
            add(j, c)
        }
        rebuildPlayer(positionMs)
    }

    // ---------- Text ----------
    fun selectText(id: Long?) {
        selectedTextId = id
    }

    fun addText() {
        val total = totalMs
        if (total <= 0) return
        val start = positionMs.coerceAtMost((total - 500).coerceAtLeast(0L))
        val end = (start + 3000).coerceAtMost(total).coerceAtLeast(start + 500)
        val item = TextItem(ids.getAndIncrement(), "Yahan text likho", start, end)
        texts = texts + item
        selectedTextId = item.id
    }

    fun editText(id: Long, f: (TextItem) -> TextItem) {
        texts = texts.map { if (it.id == id) f(it) else it }
    }

    fun deleteText(id: Long) {
        texts = texts.filter { it.id != id }
        if (selectedTextId == id) selectedTextId = null
    }

    // ---------- Music ----------
    fun setMusic(uri: Uri) {
        viewModelScope.launch {
            val info = withContext(Dispatchers.IO) {
                var name: String? = null
                try {
                    ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                        ?.use { if (it.moveToFirst()) name = it.getString(0) }
                } catch (_: Exception) {
                }
                var dur = 0L
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(ctx, uri)
                    dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                } catch (_: Exception) {
                } finally {
                    r.release()
                }
                (name ?: "Music") to dur
            }
            if (info.second <= 0L) return@launch
            music = MusicTrack(uri, info.first, info.second, 0.8f)
            musicPlayer.setMediaItem(MediaItem.fromUri(uri))
            musicPlayer.prepare()
            musicPlayer.volume = 0.8f
        }
    }

    fun setMusicVolume(v: Float) {
        music = music?.copy(volume = v)
        musicPlayer.volume = v.coerceIn(0f, 1f)
    }

    fun removeMusic() {
        music = null
        musicPlayer.stop()
        musicPlayer.clearMediaItems()
    }

    // ---------- Aspect ----------
    fun setAspect(a: AspectOption) {
        aspect = a
    }

    // ---------- Export ----------
    fun startExport() {
        if (clips.isEmpty() || exportStatus == ExportStatus.RUNNING) return
        player.pause()
        musicPlayer.pause()
        exportProgress = 0f
        exportMessage = ""

        val outFile = File(ctx.cacheDir, "export_${System.currentTimeMillis()}.mp4")
        val composition = try {
            Exporter.buildComposition(clips, texts, music, aspect, totalMs)
        } catch (e: Exception) {
            exportStatus = ExportStatus.FAILED
            exportMessage = "Setup error: ${e.message}"
            return
        }
        exportStatus = ExportStatus.RUNNING

        val t = Transformer.Builder(ctx)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    viewModelScope.launch {
                        val ok = withContext(Dispatchers.IO) {
                            val saved = Exporter.saveToGallery(ctx, outFile)
                            outFile.delete()
                            saved
                        }
                        exportProgress = 1f
                        exportStatus = if (ok) ExportStatus.DONE else ExportStatus.FAILED
                        exportMessage = if (ok) "Video Movies/VideoEditorPro me save ho gaya!"
                        else "Gallery me save nahi ho paya"
                    }
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    outFile.delete()
                    exportStatus = ExportStatus.FAILED
                    exportMessage = "Export error: ${exportException.message}"
                }
            })
            .build()
        transformer = t
        t.start(composition, outFile.absolutePath)

        viewModelScope.launch {
            val holder = ProgressHolder()
            while (exportStatus == ExportStatus.RUNNING) {
                if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                    exportProgress = holder.progress / 100f
                }
                delay(200)
            }
        }
    }

    fun cancelExport() {
        transformer?.cancel()
        exportStatus = ExportStatus.IDLE
    }

    fun dismissExport() {
        exportStatus = ExportStatus.IDLE
    }

    override fun onCleared() {
        transformer?.cancel()
        player.release()
        musicPlayer.release()
        super.onCleared()
    }
}
