package com.example.videoeditor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.videoeditor.ui.EditorScreen
import com.example.videoeditor.ui.VideoEditorTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VideoEditorTheme {
                val vm: EditorViewModel = viewModel()
                EditorScreen(vm)
            }
        }
    }
}
