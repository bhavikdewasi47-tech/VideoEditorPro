package com.example.videoeditor.engine

import android.content.ContentValues
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.provider.MediaStore
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.effect.TextOverlay
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import com.example.videoeditor.model.AspectOption
import com.example.videoeditor.model.Clip
import com.example.videoeditor.model.MusicTrack
import com.example.videoeditor.model.TextItem
import com.google.common.collect.ImmutableList
import java.io.File
import kotlin.math.min

/** Timed text overlay: sirf [startMs, endMs] ke beech dikhta hai. */
class TimedTextOverlay(
    private val item: TextItem,
    outputHeightPx: Int
) : TextOverlay() {

    private val sizePx = (item.sizeFrac * outputHeightPx).toInt().coerceAtLeast(12)

    private val visibleText: SpannableString = SpannableString(item.text).apply {
        setSpan(AbsoluteSizeSpan(sizePx, false), 0, length, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
        setSpan(ForegroundColorSpan(item.colorArgb), 0, length, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
        setSpan(StyleSpan(Typeface.BOLD), 0, length, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
    }

    private val hiddenText: SpannableString = SpannableString(" ").apply {
        setSpan(AbsoluteSizeSpan(2, false), 0, length, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
        setSpan(ForegroundColorSpan(Color.TRANSPARENT), 0, length, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
    }

    private val settings: OverlaySettings = OverlaySettings.Builder()
        .setBackgroundFrameAnchor(item.x, item.y)
        .setOverlayFrameAnchor(0f, 0f)
        .build()

    override fun getText(presentationTimeUs: Long): SpannableString {
        val ms = presentationTimeUs / 1000
        return if (ms in item.startMs..item.endMs) visibleText else hiddenText
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings = settings
}

object Exporter {

    fun outputSize(aspect: AspectOption, first: Clip?): Pair<Int, Int> = when (aspect) {
        AspectOption.R9_16 -> 1080 to 1920
        AspectOption.R16_9 -> 1920 to 1080
        AspectOption.R1_1 -> 1080 to 1080
        AspectOption.R4_5 -> 1080 to 1350
        AspectOption.ORIGINAL -> {
            val w = first?.width ?: 1920
            val h = first?.height ?: 1080
            val scale = min(1f, 1080f / min(w, h).toFloat())
            val ow = ((w * scale).toInt() / 2) * 2
            val oh = ((h * scale).toInt() / 2) * 2
            ow.coerceAtLeast(2) to oh.coerceAtLeast(2)
        }
    }

    fun buildComposition(
        clips: List<Clip>,
        texts: List<TextItem>,
        music: MusicTrack?,
        aspect: AspectOption,
        totalMs: Long
    ): Composition {
        val (outW, outH) = outputSize(aspect, clips.first())

        val editedClips = clips.map { c ->
            val mediaItem = MediaItem.Builder()
                .setUri(c.uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(c.startMs)
                        .setEndPositionMs(c.endMs)
                        .build()
                )
                .build()

            val audio = mutableListOf<AudioProcessor>()
            val video = mutableListOf<Effect>()

            if (c.speed != 1f) {
                val sonic = SonicAudioProcessor()
                sonic.setSpeed(c.speed)
                audio.add(sonic)
                video.add(SpeedChangeEffect(c.speed))
            }
            if (c.volume != 1f) {
                audio.add(VolumeProcessor(c.volume))
            }
            video.addAll(FilterEffects.forFilter(c.filter))

            EditedMediaItem.Builder(mediaItem)
                .setEffects(Effects(audio, video))
                .build()
        }

        val sequences = mutableListOf(EditedMediaItemSequence(editedClips))

        if (music != null) {
            val musicItem = MediaItem.Builder()
                .setUri(music.uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(0)
                        .setEndPositionMs(min(music.durationMs, totalMs))
                        .build()
                )
                .build()
            val editedMusic = EditedMediaItem.Builder(musicItem)
                .setRemoveVideo(true)
                .setEffects(Effects(listOf<AudioProcessor>(VolumeProcessor(music.volume)), emptyList<Effect>()))
                .build()
            sequences.add(EditedMediaItemSequence(listOf(editedMusic)))
        }

        val compositionVideoEffects = mutableListOf<Effect>(
            Presentation.createForWidthAndHeight(outW, outH, Presentation.LAYOUT_SCALE_TO_FIT)
        )
        if (texts.isNotEmpty()) {
            val overlays: List<TextureOverlay> = texts.map { TimedTextOverlay(it, outH) }
            compositionVideoEffects.add(OverlayEffect(ImmutableList.copyOf(overlays)))
        }

        return Composition.Builder(sequences)
            .setEffects(Effects(emptyList<AudioProcessor>(), compositionVideoEffects))
            .build()
    }

    fun saveToGallery(context: Context, file: File): Boolean {
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "VideoEditorPro_${System.currentTimeMillis()}.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VideoEditorPro")
            }
            val resolver = context.contentResolver
            val target = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: return false
            resolver.openOutputStream(target)?.use { out ->
                file.inputStream().use { it.copyTo(out) }
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
