package com.example.videoeditor.engine

import androidx.media3.common.Effect
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.RgbMatrix
import com.example.videoeditor.model.FilterType

object FilterEffects {

    private class SepiaMatrix : RgbMatrix {
        override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray =
            floatArrayOf(
                0.393f, 0.349f, 0.272f, 0f,
                0.769f, 0.686f, 0.534f, 0f,
                0.189f, 0.168f, 0.131f, 0f,
                0f, 0f, 0f, 1f
            )
    }

    /** Preview aur export dono me yahi effects use hote hain. */
    fun forFilter(filter: FilterType): List<Effect> = when (filter) {
        FilterType.NONE -> emptyList()
        FilterType.BW -> listOf(RgbFilter.createGrayscaleFilter())
        FilterType.SEPIA -> listOf(SepiaMatrix())
        FilterType.WARM -> listOf(
            RgbAdjustment.Builder().setRedScale(1.15f).setBlueScale(0.88f).build()
        )
        FilterType.COOL -> listOf(
            RgbAdjustment.Builder().setRedScale(0.88f).setBlueScale(1.15f).build()
        )
        FilterType.BRIGHT -> listOf(Brightness(0.15f))
        FilterType.VIVID -> listOf(Contrast(0.25f))
        FilterType.DRAMA -> listOf(Contrast(0.4f), Brightness(-0.05f))
    }
}
