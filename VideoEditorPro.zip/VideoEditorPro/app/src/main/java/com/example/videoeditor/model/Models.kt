package com.example.videoeditor.model

import android.net.Uri

enum class FilterType(val label: String) {
    NONE("Original"),
    BW("B&W"),
    SEPIA("Sepia"),
    WARM("Warm"),
    COOL("Cool"),
    BRIGHT("Bright"),
    VIVID("Vivid"),
    DRAMA("Drama")
}

data class Clip(
    val id: Long,
    val uri: Uri,
    val sourceDurationMs: Long,
    val startMs: Long,
    val endMs: Long,
    val width: Int,
    val height: Int,
    val speed: Float = 1f,
    val volume: Float = 1f,
    val filter: FilterType = FilterType.NONE
) {
    /** Timeline par is clip ki lambai (speed ke baad) */
    val effectiveDurationMs: Long
        get() = ((endMs - startMs) / speed).toLong().coerceAtLeast(1L)
}

/**
 * Text overlay. startMs / endMs timeline time me hain.
 * x, y: -1..1 (y = +1 matlab upar). sizeFrac = video ki height ka hissa.
 */
data class TextItem(
    val id: Long,
    val text: String,
    val startMs: Long,
    val endMs: Long,
    val x: Float = 0f,
    val y: Float = -0.7f,
    val sizeFrac: Float = 0.07f,
    val colorArgb: Int = 0xFFFFFFFF.toInt()
)

data class MusicTrack(
    val uri: Uri,
    val name: String,
    val durationMs: Long,
    val volume: Float = 0.8f
)

enum class AspectOption(val label: String, val ratio: Float?) {
    ORIGINAL("Original", null),
    R9_16("9:16", 9f / 16f),
    R16_9("16:9", 16f / 9f),
    R1_1("1:1", 1f),
    R4_5("4:5", 4f / 5f)
}

enum class ExportStatus { IDLE, RUNNING, DONE, FAILED }
