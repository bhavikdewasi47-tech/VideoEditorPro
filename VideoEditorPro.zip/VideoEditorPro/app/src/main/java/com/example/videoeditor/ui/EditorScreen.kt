@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.videoeditor.ui

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.videoeditor.EditorViewModel
import com.example.videoeditor.model.AspectOption
import com.example.videoeditor.model.Clip
import com.example.videoeditor.model.ExportStatus
import com.example.videoeditor.model.FilterType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class Tool(val title: String) {
    NONE(""), TRIM("Trim"), SPEED("Speed"), VOLUME("Volume"),
    FILTER("Filter"), TEXT("Text"), MUSIC("Music"), RATIO("Aspect Ratio")
}

fun fmt(ms: Long): String {
    val s = ms / 1000
    val d = (ms % 1000) / 100
    return "%d:%02d.%d".format(s / 60, s % 60, d)
}

@Composable
fun EditorScreen(vm: EditorViewModel) {
    var tool by remember { mutableStateOf(Tool.NONE) }

    val videoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(10)
    ) { uris -> vm.addClips(uris) }
    val musicPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri -> if (uri != null) vm.setMusic(uri) }

    val pickVideos = {
        videoPicker.launch(
            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
        )
    }
    val pickMusic = { musicPicker.launch("audio/*") }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // ---- Top bar ----
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Video Editor Pro", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            if (vm.isImporting) {
                Spacer(Modifier.width(12.dp))
                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
            }
            Spacer(Modifier.weight(1f))
            Button(
                onClick = { vm.startExport() },
                enabled = vm.clips.isNotEmpty()
            ) { Text("Export") }
        }

        if (vm.clips.isEmpty()) {
            EmptyState(onImport = pickVideos, modifier = Modifier.weight(1f))
        } else {
            PreviewArea(vm, Modifier.weight(1f).fillMaxWidth())

            // ---- Controls ----
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary)
                        .clickable { vm.togglePlay() },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        if (vm.isPlaying) "⏸" else "▶",
                        color = Color.Black, fontSize = 18.sp
                    )
                }
                Spacer(Modifier.width(10.dp))
                Text("${fmt(vm.positionMs)} / ${fmt(vm.totalMs)}", fontSize = 12.sp)
                Slider(
                    value = vm.positionMs.toFloat().coerceIn(0f, maxOf(vm.totalMs.toFloat(), 1f)),
                    onValueChange = { vm.seekTo(it.toLong()) },
                    valueRange = 0f..maxOf(vm.totalMs.toFloat(), 1f),
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 8.dp)
                )
            }

            Timeline(vm, onAddClip = pickVideos, onTextSelected = { tool = Tool.TEXT })

            if (tool != Tool.NONE) {
                ToolPanel(vm, tool, onClose = { tool = Tool.NONE }, pickMusic = pickMusic)
            }

            Toolbar(
                vm = vm,
                tool = tool,
                onTool = { tool = if (tool == it) Tool.NONE else it },
                onAdd = pickVideos
            )
        }
    }

    ExportDialog(vm)
}

@Composable
fun EmptyState(onImport: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("🎬", fontSize = 64.sp)
        Spacer(Modifier.height(12.dp))
        Text("Naya project shuru karo", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(
            "Video import karo, trim karo, text/music/filter lagao, export karo.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 32.dp, vertical = 8.dp)
        )
        Spacer(Modifier.height(12.dp))
        Button(onClick = onImport) { Text("+  Video import karo") }
    }
}

// ------------------------------------------------------------------
// Preview
// ------------------------------------------------------------------
@Composable
fun PreviewArea(vm: EditorViewModel, modifier: Modifier = Modifier) {
    Box(modifier.padding(horizontal = 12.dp, vertical = 4.dp), contentAlignment = Alignment.Center) {
        BoxWithConstraints(
            Modifier
                .aspectRatio(vm.previewAspect())
                .background(Color.Black)
        ) {
            val density = LocalDensity.current
            val heightPx = constraints.maxHeight.toFloat()

            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = vm.player
                        useController = false
                        resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                        setShutterBackgroundColor(android.graphics.Color.BLACK)
                    }
                },
                modifier = Modifier.fillMaxSize()
            )

            vm.texts
                .filter { vm.positionMs in it.startMs..it.endMs }
                .forEach { t ->
                    Text(
                        text = t.text,
                        color = Color(t.colorArgb),
                        fontWeight = FontWeight.Bold,
                        fontSize = with(density) { (t.sizeFrac * heightPx).toSp() },
                        modifier = Modifier.align(BiasAlignment(t.x, -t.y))
                    )
                }
        }
    }
}

// ------------------------------------------------------------------
// Timeline
// ------------------------------------------------------------------
private const val DP_PER_SEC = 36f

@Composable
fun Timeline(vm: EditorViewModel, onAddClip: () -> Unit, onTextSelected: () -> Unit) {
    val scroll = rememberScrollState()
    val density = LocalDensity.current
    var viewportW by remember { mutableIntStateOf(0) }
    val starts = remember(vm.clips) {
        vm.clips.runningFold(0L) { acc, c -> acc + c.effectiveDurationMs }
    }
    val totalDp = (vm.totalMs / 1000f * DP_PER_SEC).dp

    // Playback ke time playhead ko dikhta rakho
    LaunchedEffect(vm.positionMs) {
        if (vm.isPlaying) {
            val x = with(density) { (vm.positionMs / 1000f * DP_PER_SEC).dp.toPx() }
            scroll.scrollTo((x - viewportW / 2f).toInt().coerceAtLeast(0))
        }
    }

    Box(
        Modifier
            .fillMaxWidth()
            .height(132.dp)
            .padding(top = 6.dp)
            .onSizeChanged { viewportW = it.width }
            .horizontalScroll(scroll)
    ) {
        Column {
            // Video track
            Row {
                vm.clips.forEachIndexed { i, c ->
                    val selected = c.id == vm.activeClip?.id && vm.activeText == null
                    val w = (c.effectiveDurationMs / 1000f * DP_PER_SEC).dp.coerceAtLeast(40.dp)
                    Box(
                        Modifier
                            .width(w)
                            .height(56.dp)
                            .padding(horizontal = 1.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .border(
                                if (selected) 2.dp else 0.dp,
                                MaterialTheme.colorScheme.primary,
                                RoundedCornerShape(6.dp)
                            )
                            .pointerInput(c.id, starts[i]) {
                                detectTapGestures { off ->
                                    vm.selectClip(c.id)
                                    vm.selectText(null)
                                    vm.seekTo(starts[i] + (off.x / density.density / DP_PER_SEC * 1000).toLong())
                                }
                            }
                    ) {
                        ClipThumb(c)
                        if (c.speed != 1f) {
                            Text(
                                "${"%.1f".format(c.speed)}x",
                                fontSize = 10.sp,
                                color = Color.White,
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .background(Color(0x99000000))
                                    .padding(horizontal = 3.dp)
                            )
                        }
                    }
                }
                Box(
                    Modifier
                        .padding(start = 4.dp)
                        .size(56.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { onAddClip() },
                    contentAlignment = Alignment.Center
                ) { Text("+", fontSize = 24.sp, color = MaterialTheme.colorScheme.primary) }
            }

            Spacer(Modifier.height(6.dp))

            // Text track
            Box(Modifier.width(totalDp + 60.dp).height(26.dp)) {
                vm.texts.forEach { t ->
                    val sel = t.id == vm.activeText?.id
                    Box(
                        Modifier
                            .offset(x = (t.startMs / 1000f * DP_PER_SEC).dp)
                            .width(((t.endMs - t.startMs) / 1000f * DP_PER_SEC).dp.coerceAtLeast(30.dp))
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(5.dp))
                            .background(Color(0xFF7C4DFF))
                            .border(
                                if (sel) 2.dp else 0.dp, Color.White,
                                RoundedCornerShape(5.dp)
                            )
                            .clickable {
                                vm.selectText(t.id)
                                onTextSelected()
                            }
                            .padding(horizontal = 4.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(t.text, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Clip)
                    }
                }
            }

            Spacer(Modifier.height(4.dp))

            // Music track
            Box(Modifier.width(totalDp + 60.dp).height(24.dp)) {
                vm.music?.let { m ->
                    val w = (minOf(m.durationMs, vm.totalMs) / 1000f * DP_PER_SEC).dp
                    Box(
                        Modifier
                            .width(w.coerceAtLeast(30.dp))
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(5.dp))
                            .background(Color(0xFF2979FF))
                            .padding(horizontal = 4.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text("🎵 ${m.name}", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Clip)
                    }
                }
            }
        }

        // Playhead
        Box(
            Modifier
                .offset(x = (vm.positionMs / 1000f * DP_PER_SEC).dp)
                .width(2.dp)
                .height(120.dp)
                .background(Color.White)
        )
    }
}

@Composable
fun ClipThumb(c: Clip) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, c.uri, c.startMs) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(ctx, c.uri)
                    r.getFrameAtTime(c.startMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                } finally {
                    r.release()
                }
            }.getOrNull()
        }
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF333333))
    ) {
        bmp?.let {
            Image(
                it.asImageBitmap(), null,
                Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }
    }
}

// ------------------------------------------------------------------
// Toolbar
// ------------------------------------------------------------------
@Composable
fun ToolButton(emoji: String, label: String, active: Boolean = false, onClick: () -> Unit) {
    Column(
        Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(emoji, fontSize = 20.sp)
        Text(
            label, fontSize = 11.sp,
            color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun Toolbar(vm: EditorViewModel, tool: Tool, onTool: (Tool) -> Unit, onAdd: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .horizontalScroll(rememberScrollState())
            .padding(vertical = 4.dp)
    ) {
        ToolButton("➕", "Add") { onAdd() }
        ToolButton("✂️", "Split") { vm.splitAtPlayhead() }
        ToolButton("🎞️", "Trim", tool == Tool.TRIM) { onTool(Tool.TRIM) }
        ToolButton("⏩", "Speed", tool == Tool.SPEED) { onTool(Tool.SPEED) }
        ToolButton("🔊", "Volume", tool == Tool.VOLUME) { onTool(Tool.VOLUME) }
        ToolButton("🎨", "Filter", tool == Tool.FILTER) { onTool(Tool.FILTER) }
        ToolButton("🔤", "Text", tool == Tool.TEXT) { onTool(Tool.TEXT) }
        ToolButton("🎵", "Music", tool == Tool.MUSIC) { onTool(Tool.MUSIC) }
        ToolButton("📐", "Ratio", tool == Tool.RATIO) { onTool(Tool.RATIO) }
        ToolButton("📑", "Copy") { vm.duplicateActiveClip() }
        ToolButton("⬅️", "Left") { vm.moveActiveClip(-1) }
        ToolButton("➡️", "Right") { vm.moveActiveClip(1) }
        ToolButton("🗑️", "Delete") { vm.deleteActiveClip() }
    }
}

// ------------------------------------------------------------------
// Tool panels
// ------------------------------------------------------------------
@Composable
fun ToolPanel(vm: EditorViewModel, tool: Tool, onClose: () -> Unit, pickMusic: () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.fillMaxWidth()) {
        Column(
            Modifier
                .heightIn(max = 270.dp)
                .verticalScroll(rememberScrollState())
                .padding(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tool.title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = onClose) { Text("Done ✓") }
            }
            val clip = vm.activeClip

            when (tool) {
                Tool.TRIM -> if (clip != null) {
                    var range by remember(clip.id, clip.startMs, clip.endMs) {
                        mutableStateOf(clip.startMs.toFloat()..clip.endMs.toFloat())
                    }
                    RangeSlider(
                        value = range,
                        onValueChange = { r -> if (r.endInclusive - r.start >= 300f) range = r },
                        onValueChangeFinished = {
                            vm.trimClip(clip.id, range.start.toLong(), range.endInclusive.toLong())
                        },
                        valueRange = 0f..clip.sourceDurationMs.toFloat()
                    )
                    Text(
                        "Start ${fmt(range.start.toLong())}  •  End ${fmt(range.endInclusive.toLong())}  •  " +
                            "Length ${fmt((range.endInclusive - range.start).toLong())}",
                        fontSize = 12.sp
                    )
                }

                Tool.SPEED -> if (clip != null) {
                    Text("Speed: ${"%.2f".format(clip.speed)}x", fontSize = 13.sp)
                    Slider(
                        value = clip.speed,
                        onValueChange = { s -> vm.editClip(clip.id) { it.copy(speed = s) } },
                        valueRange = 0.25f..4f
                    )
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(0.5f, 1f, 1.5f, 2f, 3f).forEach { s ->
                            FilterChip(
                                selected = clip.speed == s,
                                onClick = { vm.editClip(clip.id) { it.copy(speed = s) } },
                                label = { Text("${s}x") }
                            )
                        }
                    }
                }

                Tool.VOLUME -> if (clip != null) {
                    Text("Clip volume: ${(clip.volume * 100).toInt()}%", fontSize = 13.sp)
                    Slider(
                        value = clip.volume,
                        onValueChange = { v -> vm.editClip(clip.id) { it.copy(volume = v) } },
                        valueRange = 0f..1f
                    )
                }

                Tool.FILTER -> if (clip != null) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterType.values().forEach { f ->
                            FilterChip(
                                selected = clip.filter == f,
                                onClick = { vm.editClip(clip.id) { it.copy(filter = f) } },
                                label = { Text(f.label) }
                            )
                        }
                    }
                    TextButton(onClick = { vm.applyFilterToAll(clip.filter) }) {
                        Text("Ye filter sab clips pe lagao")
                    }
                }

                Tool.TEXT -> TextPanel(vm)

                Tool.MUSIC -> {
                    Button(onClick = pickMusic) {
                        Text(if (vm.music == null) "Gaana chuno" else "Gaana badlo")
                    }
                    vm.music?.let { m ->
                        Text("🎵 ${m.name}", fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                        Text("Music volume: ${(m.volume * 100).toInt()}%", fontSize = 12.sp)
                        Slider(
                            value = m.volume,
                            onValueChange = { vm.setMusicVolume(it) },
                            valueRange = 0f..1f
                        )
                        TextButton(onClick = { vm.removeMusic() }) { Text("Music hatao") }
                    }
                }

                Tool.RATIO -> Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AspectOption.values().forEach { a ->
                        FilterChip(
                            selected = vm.aspect == a,
                            onClick = { vm.changeAspect(a) },
                            label = { Text(a.label) }
                        )
                    }
                }

                Tool.NONE -> {}
            }

            if (clip == null && tool in listOf(Tool.TRIM, Tool.SPEED, Tool.VOLUME, Tool.FILTER)) {
                Text("Pehle koi clip chuno.")
            }
        }
    }
}

@Composable
fun TextPanel(vm: EditorViewModel) {
    Button(onClick = { vm.addText() }) { Text("+ Playhead par text add karo") }
    val t = vm.activeText ?: return
    val total = maxOf(vm.totalMs, 1L)

    OutlinedTextField(
        value = t.text,
        onValueChange = { v -> vm.editText(t.id) { it.copy(text = v) } },
        label = { Text("Text") },
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp)
    )
    Text("Timing: ${fmt(t.startMs)} → ${fmt(t.endMs)}", fontSize = 12.sp)
    RangeSlider(
        value = t.startMs.coerceAtMost(total).toFloat()..t.endMs.coerceAtMost(total).toFloat(),
        onValueChange = { r ->
            if (r.endInclusive - r.start >= 300f) {
                vm.editText(t.id) { it.copy(startMs = r.start.toLong(), endMs = r.endInclusive.toLong()) }
            }
        },
        valueRange = 0f..total.toFloat()
    )
    Text("Size", fontSize = 12.sp)
    Slider(
        value = t.sizeFrac,
        onValueChange = { v -> vm.editText(t.id) { it.copy(sizeFrac = v) } },
        valueRange = 0.03f..0.15f
    )
    Text("Left ↔ Right", fontSize = 12.sp)
    Slider(
        value = t.x,
        onValueChange = { v -> vm.editText(t.id) { it.copy(x = v) } },
        valueRange = -0.9f..0.9f
    )
    Text("Neeche ↕ Upar", fontSize = 12.sp)
    Slider(
        value = t.y,
        onValueChange = { v -> vm.editText(t.id) { it.copy(y = v) } },
        valueRange = -0.9f..0.9f
    )
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        listOf(
            0xFFFFFFFF, 0xFFFFEB3B, 0xFFFF5252, 0xFF2EE6D6, 0xFF69F0AE, 0xFF000000
        ).forEach { col ->
            val argb = col.toInt()
            Box(
                Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(Color(argb))
                    .border(
                        if (t.colorArgb == argb) 3.dp else 1.dp,
                        if (t.colorArgb == argb) MaterialTheme.colorScheme.primary else Color.Gray,
                        CircleShape
                    )
                    .clickable { vm.editText(t.id) { it.copy(colorArgb = argb) } }
            )
        }
        Spacer(Modifier.weight(1f))
        TextButton(onClick = { vm.deleteText(t.id) }) { Text("🗑️ Delete") }
    }
}

// ------------------------------------------------------------------
// Export dialog
// ------------------------------------------------------------------
@Composable
fun ExportDialog(vm: EditorViewModel) {
    if (vm.exportStatus == ExportStatus.IDLE) return
    val running = vm.exportStatus == ExportStatus.RUNNING
    AlertDialog(
        onDismissRequest = {},
        title = {
            Text(
                when (vm.exportStatus) {
                    ExportStatus.RUNNING -> "Export ho raha hai..."
                    ExportStatus.DONE -> "Ho gaya! 🎉"
                    else -> "Export fail ❌"
                }
            )
        },
        text = {
            Column {
                if (running) {
                    LinearProgressIndicator(
                        progress = { vm.exportProgress.coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        "${(vm.exportProgress * 100).toInt()}%",
                        modifier = Modifier.padding(top = 8.dp)
                    )
                } else {
                    Text(vm.exportMessage)
                }
            }
        },
        confirmButton = {
            if (!running) TextButton(onClick = { vm.dismissExport() }) { Text("OK") }
        },
        dismissButton = {
            if (running) TextButton(onClick = { vm.cancelExport() }) { Text("Cancel") }
        }
    )
}
