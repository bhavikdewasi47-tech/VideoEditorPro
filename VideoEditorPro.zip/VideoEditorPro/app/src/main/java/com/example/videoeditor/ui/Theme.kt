package com.example.videoeditor.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun VideoEditorTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF2EE6D6),
            onPrimary = Color.Black,
            secondary = Color(0xFFFE2C55),
            background = Color(0xFF0D0D10),
            onBackground = Color.White,
            surface = Color(0xFF17171C),
            onSurface = Color.White,
            surfaceVariant = Color(0xFF24242B),
            onSurfaceVariant = Color(0xFFCCCCD6)
        ),
        content = content
    )
}
